package service;

import model.*;

import java.util.List;

public class ProductionCompanyService {

    public void addMovie(ProductionCompany productionCompany, Movie movie, App app){
        List<Show> showsCompany = productionCompany.getShows();
        showsCompany.add(movie);
        List<Show> showsApp = app.getShows();
        showsApp.add(movie);
        productionCompany.setShows(showsCompany);
        app.setShows(showsApp);

    }

    public void addSeries(ProductionCompany productionCompany, Series series, App app){
        List<Show> showsCompany = productionCompany.getShows();
        showsCompany.add(series);
        List<Show> showsApp = app.getShows();
        showsApp.add(series);
        productionCompany.setShows(showsCompany);
        app.setShows(showsApp);

    }

    public void addAwardtoActor(App app, int id, Award award){
        int ok = 0;
        for(Actor a: app.getActors()){
            if(a.getId() == id)
            {
                a.addAward(award);
                ok = 1;
            }

        }
        if(ok == 0)
            System.out.println("The Actor with id " + id + " doesn't exist");
        else if(ok == 1)
            System.out.println("Award added with succes");
    }
}
