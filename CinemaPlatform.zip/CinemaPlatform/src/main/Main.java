package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.*;
import service.AppService;
import service.CinemaGoerService;
import service.ProductionCompanyService;

public class Main {
    public static void main(String[] args) {
        App app = new App();
        AppService appService = new AppService();


       appService.initializeApp(app);


        System.out.println("Welcome to CinemaScoop!");
        System.out.println("To watch and review shows, please log in as CinemaGoer. " +
                "Enter name/address/email/phonenumber");
        System.out.println("If you are Production Company, please enter name/address/email");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        String[] attributes = input.split("/");
        if (attributes.length == 4) {
            String name = attributes[0];
            String address = attributes[1];
            String email = attributes[2];
            String phoneNumber = attributes[3];
            CinemaGoer cinemaGoer;
            if(AppService.searchUser(app, name, address, email) == true){
                cinemaGoer = new CinemaGoer(CinemaGoerService.copyUser(app, name, address, email, phoneNumber));
                System.out.println("Welcome back, " + cinemaGoer.getName() + "!");
            }
            else {
                cinemaGoer = new CinemaGoer(1, name, address, email, phoneNumber);
                System.out.println("Welcome , " + cinemaGoer.getName() + "!");

            }

            AppService.showProfile(cinemaGoer);

            while(true){
                    System.out.println("Do you want to see our shows? " + "Write yes/no");
                    String answer = scanner.nextLine();
                    List<Show> showsApp;

                    if (answer.equals("yes")) {
                            System.out.println("Do you want to see it in alphabetic order? yes/no");
                            answer = scanner.nextLine();
                            while(true){
                            if(answer.equals("yes"))
                            {
                                showsApp = AppService.ShowsInOrder(app);
                                break;
                            }

                            else if(answer.equals("no"))
                            {
                                showsApp = app.getShows();
                                break;
                            }


                            System.out.println("Please write yes or no");

                        }

                            AppService.printShows(showsApp);
                            System.out.println("Do you want to add some show in your hearted list? yes/no");
                            answer = scanner.nextLine();
                            if(answer.equals("yes")){
                                System.out.println("Write order number for the shows you want to add. Like 1 2 3");
                                input = scanner.nextLine();
                                String[] listNr = input.split(" ");
                                CinemaGoerService.addToHearted(cinemaGoer, showsApp, listNr);
                                AppService.printShows(cinemaGoer.getHearted());
                            }



                    }



                    System.out.println("Do you want to search something specific? yes/no");
                    answer = scanner.nextLine();
                    if (answer.equals("yes")) {
                            System.out.println("Write something to search ");
                            String searchedShow = scanner.nextLine();
                            List<Show> result = appService.searchShow(app, searchedShow);
                            if (result.isEmpty() == true) {
                                System.out.println("Sorry, we didn't find what you're looking for.");
                            } else {

                                for(Show s: result)
                                    System.out.println(s);
                                System.out.println("If you want to watch a show, please write the order number of the show from your search list");
                                System.out.println("If you don't, please go back ( write -1)");
                                int nrOrder = Integer.parseInt(scanner.nextLine());
                                if(nrOrder > 0){
                                    Show showToWatch = result.get(nrOrder - 1);
                                    CinemaGoerService.addToWatchList(cinemaGoer, showToWatch);
                                    System.out.println(cinemaGoer.getWatchList());
                                }

                            }
                    }
                    System.out.println("Do you want to give a review for a show from you watchList? yes/no");
                    answer = scanner.nextLine();
                    if(answer.equals("yes")){
                        List<Show> showsfromWatchList = cinemaGoer.getWatchList();
                        if(showsfromWatchList.isEmpty())
                            System.out.println("You don't have any shows in your watchList");
                        else{
                            System.out.println(showsfromWatchList);
                            System.out.println("You can pick one of the show from above. Write order number");
                            int nrOrder = Integer.parseInt(scanner.nextLine());
                            Show showToReview = showsfromWatchList.get(nrOrder - 1);
                            System.out.println("Write how many stars doo you want to give to this show and write an opinion about it.");
                            System.out.println("Like stars/opinion");
                            input = scanner.nextLine();
                            String[] review = input.split("/");
                            int stars = Integer.parseInt(review[0]);
                            Review review1 = new Review(stars, review[1], cinemaGoer, showToReview);
                            /// System.out.println(review1);
                            CinemaGoerService.giveReview(review1, showToReview);
                            System.out.println(cinemaGoer.getReviews());
                        }
                    }
                    System.out.println("Thank you for still being here! We have some amazing tops for this week:");
                    System.out.println("Top 5 awarded actors");
                    System.out.println("Shows with best reviews");
                    System.out.println("If you want to see one of the tops write an option");
                    String top = scanner.nextLine();
                    if(top.equals("Top 5 awarded actors"))
                        AppService.awardedActors(app);
                    else if(top.equals("Shows with best reviews"))
                        AppService.bestReviews(app);
                    else
                        System.out.println("Okay, maybe next time");

                    System.out.println("Do you want to see our recommendations, based on you taste? yes/no");
                    answer = scanner.nextLine();
                    if(answer.equals("yes"))
                        CinemaGoerService.recommendations(app,cinemaGoer);
                    System.out.println("If you want to close the app, write exit");
                    answer = scanner.nextLine();
                    if(answer.equals("exit")){
                        System.out.println("See you next time! Bye bye");
                        System.exit(0);
                        break;
                    }
                }
            } else if (attributes.length == 3) {
                String name = attributes[0];
                String address = attributes[1];
                String phoneNumber = attributes[2];
                ProductionCompany productionCompany = AppService.createAccount(1, name, address, phoneNumber);
                ProductionCompanyService productionCompanyService = new ProductionCompanyService();

                System.out.println("Welcome, " + productionCompany.getName() + "!");
                while(true) {
                    System.out.println("Do you want to add a show? yes/no");
                    String answear = scanner.nextLine();
                    long ct = 30;
                    if (answear.equals("yes")) {
                        System.out.println("movie or series?");
                        answear = scanner.nextLine();
                        ct++;
                        if (answear.equals("movie")) {
                            System.out.println("Please enter name/duration");
                            input = scanner.nextLine();
                            String[] movieData = input.split("/");
                            List<Actor> actors = new ArrayList<>();
                            Movie movie = new Movie(ct, movieData[0], productionCompany, actors, movieData[1]);
                            productionCompanyService.addMovie(productionCompany, movie, app);
                        } else if (answear.equals("series")) {
                            System.out.println("Please enter name/number of seasons/number of episodes");
                            input = scanner.nextLine();
                            String[] seriesData = input.split("/");
                            List<Actor> actors = new ArrayList<>();
                            Series series = new Series(ct, seriesData[0], productionCompany, actors, Integer.parseInt(seriesData[1]), Integer.parseInt(seriesData[2]));
                            productionCompanyService.addSeries(productionCompany, series, app);
                        } else
                            System.out.println("Please enter movie or series");


                    }
                    System.out.println("Do you want to add an award to an actor? yes/no");
                    input = scanner.nextLine();
                    if(input.equals("yes"))
                    {
                        AppService.printActors(app);
                        System.out.println("Write the id of the actor you want to add an award/result/name award");
                        input = scanner.nextLine();
                        String[] actorData = input.split("/");
                        Award award = new Award(actorData[1], actorData[1]);
                        int idActor = Integer.parseInt(actorData[0]);

                        productionCompanyService.addAwardtoActor(app, idActor, award);


                    }
                    System.out.println("Do you want to exit? yes/no");
                    input = scanner.nextLine();
                    if (input.equals("yes")) {
                        System.out.println("See you next time! Bye bye");
                        System.exit(0);
                        break;
                    }
                }


            }
        else {
            System.out.println("You didn't enter enough data.");
        }


        }
}
