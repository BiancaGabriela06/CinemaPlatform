package model;

public class Review {
    public final int stars;
    public final String comment;
    public final CinemaGoer cinemaGoer;

    public Show show;

    Review(){
        this.stars = 0;
        this.comment ="";
        cinemaGoer = new CinemaGoer();
        show = new Show();
    }
    public Review(int start, String comment, CinemaGoer cinemaGoer, Show show){
        this.stars = start;
        this.comment = comment;
        this.cinemaGoer = cinemaGoer;
        this.show = show;

    }

    public int getStars(){return stars;}
    public CinemaGoer getCinemaGoer(){
        return cinemaGoer;
    }

    public String toString(){
        return "Stars: " + stars + ", Opinion: " + comment + ", User: " + cinemaGoer.getName();
    }
}
