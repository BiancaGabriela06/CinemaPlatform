package model;

public class UserApp {
    private long id;
    private String name;
    private String address;
    private String email;

    public UserApp(){

    }
    public UserApp(long id){
        this.id = id;
    }

    public UserApp(long id, String name, String address, String email){
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
    }

    public UserApp(UserApp user){
        this.id = user.id;
        this.name = user.name;
        this.address = user.address;
        this.email = user.email;
    }

    ///getteri si setteri
    public long getId(){
        return id;
    }

    public void setId(long id){
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
    public String getAddress(){
        return address;
    }

    public void setAddress(){
        this.address = address;
    }

    public String getEmail(){
        return email;
    }

    public void setEmail(){
        this.email = email;
    }

    public String toString(){
        return "User's id: "+ id + ", name: " + name + ", address: " + address + ", email: " + email ;
    }
}
