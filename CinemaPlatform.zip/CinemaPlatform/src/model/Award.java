package model;

public class Award {
    private final String result; /// nominee, winner
    private final String nameAward;

    public Award(String result, String nameAward){
        this.result = result;
        this.nameAward = nameAward;
    }

}
