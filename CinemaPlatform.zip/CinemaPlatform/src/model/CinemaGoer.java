package model;

import java.util.*;

public class CinemaGoer extends UserApp {

    public String phoneNumber;
    protected List<Show> hearted;
    protected List<Review> reviews;
    protected List<Show> watchList;

    ///Constructori
    CinemaGoer(){
        super(1);
        this.phoneNumber = "";
        reviews = new ArrayList<>();
        watchList = new ArrayList<>();
        hearted = new ArrayList<>();

    }

    public CinemaGoer(long id, String name, String address, String email, String phoneNumber){
        super(id, name, address, email);
        this.phoneNumber = phoneNumber;
        reviews = new ArrayList<>();
        watchList = new ArrayList<>();
        hearted = new ArrayList<>();
    }

    public CinemaGoer(CinemaGoer cinemaGoer){
        super(cinemaGoer.getId(), cinemaGoer.getName(), cinemaGoer.getAddress(), cinemaGoer.getEmail());
        this.phoneNumber = cinemaGoer.phoneNumber;
    }
    ///getteri si setteri

    public String getPhoneNumber(){
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    public List<Review> getReviews(){
        return reviews;
    }
    public void setReviews(List<Review> reviews){
        this.reviews = reviews;
    }
    public List<Show> getWatchList(){
        return watchList;
    }

    public void setWatchList(List<Show> shows){
        this.watchList = shows;
    }

    public void setHearted(List<Show> hearted){
        this.hearted = hearted;
    }
    public List<Show> getHearted(){
        return hearted;
    }
    Review addReview(int showId) /// user ul adauga un review la show ul cu id-ul resp
    {
        Review review = new Review();

        return review;

    }

    @Override
    public String toString(){
        return super.toString() + ", phoneNumber: " + phoneNumber;
    }

}
