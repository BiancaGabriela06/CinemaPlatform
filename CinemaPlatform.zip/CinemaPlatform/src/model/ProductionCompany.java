package model;

import java.util.ArrayList;
import java.util.List;

public class ProductionCompany extends UserApp{
    protected List<Show> shows;

    public ProductionCompany(long id, String name, String address, String email){
        super(id, name, address, email);
        shows = new ArrayList<>();
    }

    protected ProductionCompany(ProductionCompany productionCompany){
        super(1);
        this.shows = productionCompany.shows;

    }

    public List<Show> getShows(){
        return shows;
    }
    public void setShows(List<Show> shows){
        this.shows = shows;
    }

    public void addShow(Show show){
        shows.add(show);
    }
}
