package model;

import java.util.ArrayList;
import java.util.List;

public class Actor {
    private int id;
    private final String name;
    private final Number age;
    private List<Award> awards;

    public Actor(int id, String name, Number age){
        this.id = id;
        this.age = age;
        this.name = name;
        awards = new ArrayList<>();
    }

    public long getId(){
        return id;
    }

    public List<Award> getAwards(){
        return awards;
    }

    public void setAwards(List<Award> awards){
        this.awards = awards;
    }
    public void addAward(Award award){
           awards.add(award);
    }

    public String toString(){
        return "Actor's name: " + name + ", age " + age;
    }

}
